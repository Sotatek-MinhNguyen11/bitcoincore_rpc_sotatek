bitcoincore-rpc
===============

Rust client library for the Bitcoin Core daemon's JSON-RPC API.

Separate `bitcoincore-rpc-json` crate with the JSON-enabled data types used 
in the interface of this crate.


## MSRV

please see the parent README for the current MSRV.

# License

All code is licensed using the CC0 license, as per the LICENSE file.
